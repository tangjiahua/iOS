//
//  SVItemModel.h
//  ShortVideo
//
//  Created by ByteDance on 2019/7/8.
//  Copyright © 2019 Bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SVItemModel : NSObject

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *imageName;

- (instancetype)initWithTitle:(NSString *)title
                    imageName:(NSString *)imageName;

@end

NS_ASSUME_NONNULL_END
