//
//  SVItemModel.m
//  ShortVideo
//
//  Created by ByteDance on 2019/7/8.
//  Copyright © 2019 Bytedance. All rights reserved.
//

#import "SVItemModel.h"

@implementation SVItemModel

- (instancetype)initWithTitle:(NSString *)title imageName:(NSString *)imageName {
    self = [super init];
    if (self) {
        self.title = title;
        self.imageName = imageName;
    }
    return self;
}

@end
