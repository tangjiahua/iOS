//
//  SVDetailPushTransition.h
//  ShortVideo
//
//  Created by ByteDance on 2019/7/8.
//  Copyright © 2019 Bytedance. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol SVDetailPushTransitionFromVC <NSObject>

- (UIImageView *)transitionImageView;

@end

@protocol SVDetailPushTransitionToVC <NSObject>

- (CGRect)transitionViewTargetFrame;
- (UIImageView *)transitionTargetView;

@end

@interface SVDetailPushTransition : NSObject <UIViewControllerAnimatedTransitioning>

@end

NS_ASSUME_NONNULL_END
