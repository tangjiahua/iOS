//
//  SVDetailPushTransition.m
//  ShortVideo
//
//  Created by ByteDance on 2019/7/8.
//  Copyright © 2019 Bytedance. All rights reserved.
//

#import "SVDetailPushTransition.h"

@implementation SVDetailPushTransition

- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return 4;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    UIViewController<SVDetailPushTransitionFromVC> *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIViewController<SVDetailPushTransitionToVC> *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    
    UIImageView *fromTransitionView = [fromVC transitionImageView];
    UIImageView *snapshotView = [[UIImageView alloc] initWithImage:fromTransitionView.image];
    snapshotView.contentMode = UIViewContentModeScaleAspectFill;
    snapshotView.clipsToBounds = YES;
    
    UIImageView *targetView = [toVC transitionTargetView];
    
    UIView *containerView = transitionContext.containerView;
    
    [containerView addSubview:toVC.view];
    [containerView addSubview:snapshotView];
    toVC.view.alpha = 0;
    fromTransitionView.hidden = YES;
    targetView.hidden = YES;
    
    CGRect snapshotInitFrame = [containerView convertRect:fromTransitionView.bounds fromView:fromTransitionView];
    if (fromTransitionView.contentMode == UIViewContentModeScaleAspectFit) {
        snapshotInitFrame = [self aspectFitFrameInRect:snapshotInitFrame forImage:snapshotView.image];
    }
    
    CGRect snapshotFinalFrame = [toVC transitionViewTargetFrame];
    if (targetView.contentMode == UIViewContentModeScaleAspectFit) {
        snapshotFinalFrame = [self aspectFitFrameInRect:snapshotFinalFrame forImage:snapshotView.image];
    }
    
    snapshotView.frame = snapshotInitFrame;
    
    [UIView animateWithDuration:[self transitionDuration:transitionContext] animations:^{
        toVC.view.alpha = 1;
        snapshotView.frame = snapshotFinalFrame;
    } completion:^(BOOL finished) {
        [snapshotView removeFromSuperview];
        targetView.hidden = NO;
        fromTransitionView.hidden = NO;
        [transitionContext completeTransition:finished];
    }];
}

- (CGRect)aspectFitFrameInRect:(CGRect)rect forImage:(UIImage *)image
{
    if (image.size.width / image.size.height > rect.size.width / rect.size.height) {
        // image is wider
        CGRect imageFrame = rect;
        imageFrame.size.height = rect.size.width / image.size.width * image.size.height;
        imageFrame.origin.y += (rect.size.height - imageFrame.size.height) / 2;
        return imageFrame;
    } else {
        // rect is wider
        CGRect imageFrame = rect;
        imageFrame.size.width = rect.size.height / image.size.height * image.size.width;
        imageFrame.origin.x += (rect.size.width - imageFrame.size.width) / 2;
        return imageFrame;
    }
}

@end
