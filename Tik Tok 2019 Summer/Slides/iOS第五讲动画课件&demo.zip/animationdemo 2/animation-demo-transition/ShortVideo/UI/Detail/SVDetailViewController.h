//
//  SVDetailViewController.h
//  ShortVideo
//
//  Created by ByteDance on 2019/7/8.
//  Copyright © 2019 Bytedance. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SVItemModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SVDetailViewController : UIViewController

- (instancetype)initWithItem:(SVItemModel *)item;

@end

NS_ASSUME_NONNULL_END
