//
//  SVDetailViewController.m
//  ShortVideo
//
//  Created by ByteDance on 2019/7/8.
//  Copyright © 2019 Bytedance. All rights reserved.
//

#import "SVDetailViewController.h"
#import "SVDetailPushTransition.h"

@interface SVDetailViewController () <SVDetailPushTransitionToVC, SVDetailPushTransitionFromVC>

@property (nonatomic, strong) SVItemModel *item;
@property (nonatomic, strong) UIImageView *imageView;

@end

@implementation SVDetailViewController

- (instancetype)initWithItem:(SVItemModel *)item {
    self = [super init];
    if (self) {
        self.item = item;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.item.title;
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.imageView];
}

#pragma mark - Layout
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.imageView.frame = self.view.bounds;
}

#pragma mark - Getters
- (UIImageView *)imageView
{
    if (!_imageView) {
        _imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:self.item.imageName]];
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _imageView;
}

#pragma mark - SVDetailPushTransitionToVC
- (CGRect)transitionViewTargetFrame {
    return self.view.frame;
}

- (UIImageView *)transitionTargetView {
    return self.imageView;
}

#pragma mark - SVDetailPushTransitionFromVC
- (UIImageView *)transitionImageView
{
    return self.imageView;
}

@end
