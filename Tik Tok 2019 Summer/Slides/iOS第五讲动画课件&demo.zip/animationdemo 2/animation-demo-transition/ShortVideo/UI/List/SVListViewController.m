//
//  SVListViewController.m
//  ShortVideo
//
//  Created by ByteDance on 2019/7/8.
//  Copyright © 2019 Bytedance. All rights reserved.
//

#import "SVListViewController.h"
#import "SVItemModel.h"
#import "SVListTableViewCell.h"
#import "SVDetailViewController.h"
#import "SVDetailPushTransition.h"

NSString * const cellReuseIdentifier = @"SVListTableViewCell";

@interface SVListViewController () <UITableViewDelegate, UITableViewDataSource, SVDetailPushTransitionFromVC, SVDetailPushTransitionToVC, UINavigationControllerDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray<SVItemModel *> *items;

@end

@implementation SVListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Image List";
    [self.view addSubview:self.tableView];
    
    self.items = @[
                   [[SVItemModel alloc] initWithTitle:@"OS X Yosemite" imageName:@"Yosemite"],
                   [[SVItemModel alloc] initWithTitle:@"OS XI El Captain" imageName:@"El Capitan"],
                   [[SVItemModel alloc] initWithTitle:@"macOS Sierra" imageName:@"Sierra"],
                   [[SVItemModel alloc] initWithTitle:@"macOS High Sierra" imageName:@"High Sierra"],
                   [[SVItemModel alloc] initWithTitle:@"macOS Mojave" imageName:@"Mojave Day"],
                   [[SVItemModel alloc] initWithTitle:@"macOS Catalina" imageName:@"Catalina"],
                   ];
    
    self.navigationController.delegate = self;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.tableView deselectRowAtIndexPath:self.tableView.indexPathForSelectedRow animated:YES];
}

#pragma mark - Layout
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.tableView.frame = self.view.bounds;
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SVListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellReuseIdentifier];
    [cell configWithModel:self.items[indexPath.row]];
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    SVDetailViewController *detailViewController = [[SVDetailViewController alloc] initWithItem:self.items[indexPath.row]];
    [self.navigationController pushViewController:detailViewController animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

#pragma mark - SVDetailPushTransitionFromVC
- (UIImageView *)transitionImageView {
    SVListTableViewCell *selectedCell = [self.tableView cellForRowAtIndexPath:self.tableView.indexPathForSelectedRow];
    return selectedCell.iconImageView;
}

#pragma mark - SVDetailPushTransitionToVC
- (UIImageView *)transitionTargetView {
    return self.transitionImageView;
}

- (CGRect)transitionViewTargetFrame {
    UIView *transitionView = self.transitionImageView;
    return [self.view convertRect:transitionView.bounds fromView:transitionView];
}

#pragma mark - UINavigationControllerDelegate
- (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController animationControllerForOperation:(UINavigationControllerOperation)operation fromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC
{
    if ([fromVC conformsToProtocol:@protocol(SVDetailPushTransitionFromVC)] &&
        [toVC conformsToProtocol:@protocol(SVDetailPushTransitionToVC)]) {
        return [SVDetailPushTransition new];
    }
    
    return nil;
}

#pragma mark - Getters
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        [_tableView registerClass:[SVListTableViewCell class] forCellReuseIdentifier:cellReuseIdentifier];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}

@end
