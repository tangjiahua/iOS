//
//  SVListTableViewCell.m
//  ShortVideo
//
//  Created by ByteDance on 2019/7/8.
//  Copyright © 2019 Bytedance. All rights reserved.
//

#import "SVListTableViewCell.h"

@implementation SVListTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self.contentView addSubview:self.iconImageView];
        [self.contentView addSubview:self.titleLabel];
    }
    return self;
}

- (void)configWithModel:(SVItemModel *)item {
    self.titleLabel.text = item.title;
    self.iconImageView.image = [UIImage imageNamed:item.imageName];
}

#pragma mark - Layout
- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat verticalMargin = 8.f;
    CGFloat horizontalMargin = 16.f;
    CGFloat aspectRatio = 3.f / 4.f;
    
    CGFloat imageViewHeight = CGRectGetHeight(self.contentView.bounds) - verticalMargin * 2;
    CGFloat imageViewWidth = imageViewHeight * aspectRatio;
    
    CGFloat labelHeight = imageViewHeight;
    CGFloat labelWidth = CGRectGetWidth(self.contentView.bounds) - horizontalMargin * 3 - imageViewWidth;
    
    CGRect imageFrame = CGRectMake(horizontalMargin, verticalMargin, imageViewWidth, imageViewHeight);
    CGRect labelFrame = CGRectMake(CGRectGetMaxX(imageFrame) + horizontalMargin, verticalMargin, labelWidth, labelHeight);
    
    self.iconImageView.frame = imageFrame;
    self.titleLabel.frame = labelFrame;
}

#pragma mark - Getters
- (UIImageView *)iconImageView {
    if (!_iconImageView) {
        _iconImageView = [[UIImageView alloc] init];
        _iconImageView.clipsToBounds = YES;
        _iconImageView.contentMode = UIViewContentModeScaleAspectFill;
    }
    return _iconImageView;
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
    }
    return _titleLabel;
}

@end
