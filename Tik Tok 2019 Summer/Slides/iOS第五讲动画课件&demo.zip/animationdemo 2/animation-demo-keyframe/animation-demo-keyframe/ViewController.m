//
//  ViewController.m
//  animation-demo-keyframe
//
//  Created by lianweiqin on 2019/7/11.
//  Copyright © 2019 ByteDance. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic, strong) UIView *circle;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor blackColor];

    [self.view addSubview:self.circle];

    [self createButtons];

    [self createPositionKeyframeAnima];         // 1. 位移动画
}

- (void)createButtons
{
    UIButton *actionBtn = [[UIButton alloc] initWithFrame:CGRectMake(150, 700, 100, 40)];
    [actionBtn setTitle:@"animate" forState:UIControlStateNormal];
    [actionBtn addTarget:self action:@selector(onActionBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:actionBtn];

    UIButton *resetBtn = [[UIButton alloc] initWithFrame:CGRectMake(150, 750, 100, 40)];
    [resetBtn setTitle:@"reset" forState:UIControlStateNormal];
    [resetBtn addTarget:self action:@selector(onResetBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:resetBtn];
}

#pragma mark - Actions

- (void)onActionBtnClicked
{
//    [self createDampingAnimation];      // 2. 使用 UIView api 创建一个简单的弹性动画

    [self createKeyframeDampAnimation];     // 3. 使用keyframe实现弹性
}

- (void)onResetBtnClicked
{
    self.circle.center = CGPointMake(100, 100);
}

#pragma mark - Animation

- (void)createPositionKeyframeAnima
{
    CAKeyframeAnimation *keyframeAnima = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    keyframeAnima.values = @[ [NSValue valueWithCGPoint:CGPointMake(150, 32)],
                              [NSValue valueWithCGPoint:CGPointMake(10, 430)],
                              [NSValue valueWithCGPoint:CGPointMake(200, 200)],
                              [NSValue valueWithCGPoint:CGPointMake(340, 600)],
                              [NSValue valueWithCGPoint:CGPointMake(100, 40)],
                              [NSValue valueWithCGPoint:CGPointMake(80, 560)],
                              [NSValue valueWithCGPoint:CGPointMake(300, 390)],
                              [NSValue valueWithCGPoint:CGPointMake(200, 200)]];
    keyframeAnima.duration = 5;
    [self.circle.layer addAnimation:keyframeAnima forKey:nil];
}

- (void)createDampingAnimation
{
    [UIView animateWithDuration:2
                          delay:0.1
         usingSpringWithDamping:0.5
          initialSpringVelocity:0
                        options:UIViewAnimationOptionCurveEaseInOut animations:^{
                            self.circle.center = CGPointMake(100, 400);
                        } completion:nil];
}

- (void)createKeyframeDampAnimation
{
    CAKeyframeAnimation *keyframeAnima = [CAKeyframeAnimation animationWithKeyPath:@"position.y"];
    NSMutableArray *values = [NSMutableArray arrayWithObjects:@125, @450, nil];
    NSMutableArray *keyTimes = [NSMutableArray arrayWithObjects:@0, @0.5, nil];
    NSMutableArray *timingFunctions = [NSMutableArray arrayWithObjects:[CAMediaTimingFunction functionWithControlPoints:0.62 :0.14 :0.88 :0.41], nil];
    for (NSInteger i = 0; i < 60; i++) {
        CGFloat damp = 5.0 / 60 * (i + 1);
        CGFloat y = 400 + 50.0 * pow(M_E, -damp) * cos(damp * 2 * M_PI);
        [values addObject:@(y)];
        [keyTimes addObject:@(0.5 + 0.5 / 60 * (i + 1))];
        [timingFunctions addObject:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]];
    }
    keyframeAnima.values = values;
    keyframeAnima.keyTimes = keyTimes;
    keyframeAnima.duration = 2;
    keyframeAnima.timingFunctions = timingFunctions;
    [self.circle.layer addAnimation:keyframeAnima forKey:nil];
}

#pragma mark - Property

- (UIView *)circle
{
    if (!_circle) {
        _circle = [[UIView alloc] initWithFrame:CGRectMake(100, 100, 50, 50)];
        _circle.layer.cornerRadius = 25;
        _circle.backgroundColor = [UIColor colorWithRed:0 green:0.63 blue:1 alpha:1];
    }
    return _circle;
}

@end
