//
//  AppDelegate.h
//  UIDynamicExample
//
//  Created by jli on 11/8/13.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
