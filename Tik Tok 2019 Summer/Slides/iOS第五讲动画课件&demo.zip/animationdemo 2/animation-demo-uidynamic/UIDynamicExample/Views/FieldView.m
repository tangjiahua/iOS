//
//  FieldView.m
//  UIDynamicExample
//
//  Created by lianweiqin on 2019/7/15.
//

#import "FieldView.h"

@implementation FieldView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self addField];
    }
    return self;
}

- (void)addField
{
    theAnimator = [[UIDynamicAnimator alloc] initWithReferenceView:self];
    UIFieldBehavior *fieldBehavior = [UIFieldBehavior velocityFieldWithVector:CGVectorMake(1, 1)];
    [fieldBehavior addItem:ballView];
    [theAnimator addBehavior:fieldBehavior];
}

@end
