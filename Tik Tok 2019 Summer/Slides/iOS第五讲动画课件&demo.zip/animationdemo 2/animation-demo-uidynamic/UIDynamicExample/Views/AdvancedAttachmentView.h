#import <Foundation/Foundation.h>

@interface AdvancedAttachmentView : UIView
@end