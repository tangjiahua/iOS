#import <Foundation/Foundation.h>

@interface PushView : UIView
@end