//
//  CircleProgressView.m
//  animation-demo-progress
//
//  Created by lianweiqin on 2019/7/1.
//  Copyright © 2019 连伟钦. All rights reserved.
//

#import "CircleProgressView.h"

const CGFloat barHeight = 30;
const CGFloat barWidth = 200;

@interface CircleProgressView()<CAAnimationDelegate>

@property (nonatomic, strong) UIView *circle;
@property (nonatomic, assign) CGRect originFrame;

@end

@implementation CircleProgressView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        CGFloat width = 100;
        UIView *circle = [[UIView alloc] initWithFrame:CGRectMake(0, 0, width, width)];
        circle.center = CGPointMake(frame.size.width / 2, 200);
        circle.layer.cornerRadius = width / 2;
        circle.backgroundColor = [UIColor colorWithRed:0 green:0.63 blue:1 alpha:1];
        [self addSubview:circle];

        UITapGestureRecognizer *recog = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapped:)];
        circle.userInteractionEnabled = YES;
        [circle addGestureRecognizer:recog];
        self.circle = circle;
    }
    return self;
}

- (void)tapped:(UITapGestureRecognizer *)tapped
{
    self.originFrame = self.circle.frame;
    if (self.isAnimating) {
        return;
    }
    self.isAnimating = YES;
    self.circle.backgroundColor = [UIColor colorWithRed:0 green:0.63 blue:1 alpha:1];
    for (CALayer *subLayer in self.circle.layer.sublayers) {
        [subLayer removeFromSuperlayer];
    }

    self.circle.layer.cornerRadius = barHeight / 2;
    CABasicAnimation *radiusAnimation = [CABasicAnimation animationWithKeyPath:@"cornerRadius"];
    radiusAnimation.duration = 0.2f;
    radiusAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    radiusAnimation.fromValue = @(self.originFrame.size.height / 2);
    radiusAnimation.delegate = self;
    [self.circle.layer addAnimation:radiusAnimation forKey:@"cornerRadiusAnim"];
}

- (void)progressBarAnimation
{
    CAShapeLayer *progressLayer = [CAShapeLayer layer];
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(barHeight / 2, self.circle.bounds.size.height / 2)];
    [path addLineToPoint:CGPointMake(self.circle.bounds.size.width - barHeight / 2, self.circle.bounds.size.height / 2)];
    progressLayer.path = path.CGPath;
    progressLayer.strokeColor = [UIColor whiteColor].CGColor;
    progressLayer.lineWidth = barHeight - 8;
    progressLayer.lineCap = kCALineCapRound;
    [self.circle.layer addSublayer:progressLayer];

    CABasicAnimation *pathAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    pathAnimation.duration = 2.0f;
    pathAnimation.fromValue = @(0.0f);
    pathAnimation.toValue = @(1.0f);
    pathAnimation.delegate = self;
    [pathAnimation setValue:@"progressBarAnimation" forKey:@"animation_name"];
    [progressLayer addAnimation:pathAnimation forKey:nil];
}

- (void)checkAnimation
{
    CAShapeLayer *checkLayer = [CAShapeLayer layer];
    UIBezierPath *path = [UIBezierPath bezierPath];

    CGRect rectInCircle = CGRectInset(self.circle.bounds, self.circle.bounds.size.width * (1 - 1 / sqrt(2.0)) / 2, self.circle.bounds.size.width * (1 - 1 / sqrt(2.0)) / 2);
    [path moveToPoint:CGPointMake(rectInCircle.origin.x + rectInCircle.size.width / 9, rectInCircle.origin.y + rectInCircle.size.height * 2 / 3)];

    [path addLineToPoint:CGPointMake(rectInCircle.origin.x + rectInCircle.size.width / 3, rectInCircle.origin.y + rectInCircle.size.height * 9 / 10)];
    [path addLineToPoint:CGPointMake(rectInCircle.origin.x + rectInCircle.size.width * 8 / 10, rectInCircle.origin.y + rectInCircle.size.height * 2 / 10)];

    checkLayer.path = path.CGPath;
    checkLayer.fillColor = [UIColor clearColor].CGColor;
    checkLayer.strokeColor = [UIColor whiteColor].CGColor;
    checkLayer.lineWidth = 10.0;
    checkLayer.lineCap = kCALineCapRound;
    checkLayer.lineJoin = kCALineJoinRound;
    [self.circle.layer addSublayer:checkLayer];
    CABasicAnimation *checkAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    checkAnimation.duration = 0.3f;
    checkAnimation.fromValue = @(0.0f);
    checkAnimation.toValue = @(1.0f);
    checkAnimation.delegate = self;
    [checkAnimation setValue:@"checkAnimation" forKey:@"animationName"];
    [checkLayer addAnimation:checkAnimation forKey:nil];
}

#pragma mark - CAAnimationDelegate

- (void)animationDidStart:(CAAnimation *)anim
{
    if ([anim isEqual:[self.circle.layer animationForKey:@"cornerRadiusAnim"]]) {
        [UIView animateWithDuration:0.6f
                              delay:0.0f
             usingSpringWithDamping:0.6
              initialSpringVelocity:0.0
                            options:UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             self.circle.bounds = CGRectMake(0, 0, barWidth, barHeight);
                         } completion:^(BOOL finished) {
                             [self.circle.layer removeAllAnimations];
                             [self progressBarAnimation];
                         }];
    } else if ([anim isEqual:[self.circle.layer animationForKey:@"cornerRadiusExpandAnim"]]) {
        [UIView animateWithDuration:0.6f
                              delay:0.0f
             usingSpringWithDamping:0.6
              initialSpringVelocity:0.0
                            options:UIViewAnimationOptionCurveEaseOut
                         animations:^{
                             self.circle.bounds = CGRectMake(0, 0, self.originFrame.size.width, self.originFrame.size.height);
                             self.circle.backgroundColor = [UIColor colorWithRed:0.12 green:0.7 blue:0 alpha:1.0];
                         }
                         completion:^(BOOL finished) {
                             [self.circle.layer removeAllAnimations];
                             [self checkAnimation];
                             self.isAnimating = NO;
                         }];
    }
}

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    if ([[anim valueForKey:@"animation_name"] isEqualToString:@"progressBarAnimation"]) {
        [UIView animateWithDuration:0.3 animations:^{
            for (CALayer *subLayer in self.circle.layer.sublayers) {
                subLayer.opacity = 0.0f;
            }
        } completion:^(BOOL finished) {
            for (CALayer *subLayer in self.circle.layer.sublayers) {
                [subLayer removeFromSuperlayer];
            }
            self.circle.layer.cornerRadius = self.originFrame.size.height / 2;
            CABasicAnimation *radiusAnimation = [CABasicAnimation animationWithKeyPath:@"cornerRadius"];
            radiusAnimation.duration = 0.2f;
            radiusAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
            radiusAnimation.fromValue = @(barHeight / 2);
            radiusAnimation.delegate = self;
            [self.circle.layer addAnimation:radiusAnimation forKey:@"cornerRadiusExpandAnim"];
        }];
    }
}

@end
