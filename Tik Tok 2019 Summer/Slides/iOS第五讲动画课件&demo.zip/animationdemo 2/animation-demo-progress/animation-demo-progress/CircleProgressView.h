//
//  CircleProgressView.h
//  animation-demo-progress
//
//  Created by lianweiqin on 2019/7/1.
//  Copyright © 2019 连伟钦. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CircleProgressView : UIView

@property (nonatomic, assign) BOOL isAnimating;


@end

NS_ASSUME_NONNULL_END
