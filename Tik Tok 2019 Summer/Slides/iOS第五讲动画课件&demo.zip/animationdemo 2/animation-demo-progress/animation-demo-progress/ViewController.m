//
//  ViewController.m
//  animation-demo-progress
//
//  Created by lianweiqin on 2019/7/1.
//  Copyright © 2019 连伟钦. All rights reserved.
//

#import "ViewController.h"
#import "CircleProgressView.h"

@interface ViewController ()

@property (nonatomic, strong) CircleProgressView *progressView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor blackColor];

    self.progressView = [[CircleProgressView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:self.progressView];
}

@end
