//
//  ViewController.m
//  animation-demo
//
//  Created by lianweiqin on 2019/6/30.
//  Copyright © 2019 ByteDance. All rights reserved.
//

#import "ViewController.h"

#define WIDTH 100.0

@interface ViewController ()

@property (nonatomic, strong) UIView *circle;

@property (nonatomic, strong) CALayer *someLayer;

@property (nonatomic, strong) UIButton *animateBtn;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

//    [self.view.layer addSublayer:self.someLayer];     // last. 隐式动画
    [self.view addSubview:self.circle];
    [self.view addSubview:self.animateBtn];

//    [self positionAnimationUIView];     // 0. UIView 位移
//    [self positionAnimation];           // 1. 位移动画
//    [self scaleAnimation];              // 2. 放大缩小动画
//    [self rotateAnimation];             // 3. 旋转动画
//    [self colorAnimation];              // 4. 颜色动画

//    [self groupAnimation];                // 6. group
}

#pragma mark - Action

- (void)onBtnClicked
{
    self.someLayer.position = CGPointMake(arc4random() % 375, arc4random() % 800);
    self.circle.layer.position = CGPointMake(arc4random() % 375, arc4random() % 800);
    self.circle.layer.cornerRadius = arc4random() % 50;
}

#pragma mark - Animation

- (void)positionAnimationUIView
{
    [UIView animateWithDuration:1.5
                     animations:^{
                         self.circle.frame = CGRectMake(self.circle.frame.origin.x + 100,
                                                        self.circle.frame.origin.y,
                                                        self.circle.frame.size.width,
                                                        self.circle.frame.size.height);
                     }
                     completion:nil];
}

- (void)positionAnimation
{
    CABasicAnimation *moveAnimation = [CABasicAnimation animationWithKeyPath:@"position.x"];
    moveAnimation.fromValue = @(self.circle.center.x);
    moveAnimation.toValue = @(self.circle.center.x + 100);
    moveAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    moveAnimation.duration = 1.5;
    moveAnimation.removedOnCompletion = NO;
    moveAnimation.fillMode = kCAFillModeForwards;
    [self.circle.layer addAnimation:moveAnimation forKey:nil];
}

- (void)rotateAnimation
{
    CABasicAnimation *rotateAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.x"];
    rotateAnimation.fromValue = @(0);
    rotateAnimation.toValue = @(2 * M_PI);
    rotateAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    rotateAnimation.duration = 5;
    [self.circle.layer addAnimation:rotateAnimation forKey:nil];
}

- (void)scaleAnimation
{
    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    scaleAnimation.fromValue = @(0.5);
    scaleAnimation.toValue = @(2);
    scaleAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    scaleAnimation.duration = 1.5;
    [self.circle.layer addAnimation:scaleAnimation forKey:nil];
}

- (void)colorAnimation
{
    CABasicAnimation *colorAnimation = [CABasicAnimation animationWithKeyPath:@"backgroundColor"];
    colorAnimation.fromValue = (__bridge id _Nullable)([UIColor colorWithRed:0 green:0.63 blue:1 alpha:1].CGColor);
    colorAnimation.toValue = (__bridge id _Nullable)([UIColor redColor].CGColor);
    colorAnimation.duration = 2;
    colorAnimation.removedOnCompletion = NO;
    colorAnimation.fillMode = kCAFillModeForwards;
    [self.circle.layer addAnimation:colorAnimation forKey:nil];
}

- (void)groupAnimation
{
    CABasicAnimation *colorAnimation = [CABasicAnimation animationWithKeyPath:@"backgroundColor"];
    colorAnimation.fromValue = (__bridge id _Nullable)([UIColor colorWithRed:0 green:0.63 blue:1 alpha:1].CGColor);
    colorAnimation.toValue = (__bridge id _Nullable)([UIColor redColor].CGColor);

    CABasicAnimation *moveAnimation = [CABasicAnimation animationWithKeyPath:@"position.x"];
    moveAnimation.fromValue = @(self.circle.center.x);
    moveAnimation.toValue = @(self.circle.center.x + 100);

    CAAnimationGroup *group = [CAAnimationGroup animation];
    group.duration = 2;
    group.animations = @[moveAnimation, colorAnimation];
    group.removedOnCompletion = NO;
    group.fillMode = kCAFillModeForwards;
    [self.circle.layer addAnimation:group forKey:nil];
}

#pragma mark - Property

- (UIView *)circle
{
    if (!_circle) {
        _circle = [[UIView alloc] initWithFrame:CGRectMake(100, 100, WIDTH, WIDTH)];
//        _circle.layer.anchorPoint = CGPointMake(0, 1);        // 5. 锚点改变
        _circle.layer.cornerRadius = WIDTH / 2;
        _circle.backgroundColor = [UIColor colorWithRed:0 green:0.63 blue:1 alpha:1];
    }
    return _circle;
}

- (CALayer *)someLayer
{
    if (!_someLayer) {
        _someLayer = [CALayer layer];
        _someLayer.frame = CGRectMake(100, 100, WIDTH, WIDTH);
        _someLayer.backgroundColor = [UIColor redColor].CGColor;
    }
    return _someLayer;
}

- (UIButton *)animateBtn
{
    if (!_animateBtn) {
        _animateBtn = [[UIButton alloc] initWithFrame:CGRectMake(150, 600, 100, 40)];
        [_animateBtn setTitle:@"animate"
                     forState:UIControlStateNormal];
        [_animateBtn setTitleColor:[UIColor blackColor]
                          forState:UIControlStateNormal];
        [_animateBtn addTarget:self action:@selector(onBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _animateBtn;
}

@end
