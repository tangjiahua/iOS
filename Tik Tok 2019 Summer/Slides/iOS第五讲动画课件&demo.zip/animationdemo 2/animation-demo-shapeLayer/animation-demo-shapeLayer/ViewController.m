//
//  ViewController.m
//  animation-demo-shapeLayer
//
//  Created by lianweiqin on 2019/7/2.
//  Copyright © 2019 连伟钦. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic, strong) CAShapeLayer *shapeLayer;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor blackColor];

    [self.view.layer addSublayer:self.shapeLayer];

    UIBezierPath *path = [self rectPath];
//    UIBezierPath *path = [self roundPath];
//    UIBezierPath *path = [self roundRectPath];
//    UIBezierPath *path = [self rectCornersPath];
//    UIBezierPath *path = [self trianglePath];
//    UIBezierPath *path = [self bazierPath];
    self.shapeLayer.path = path.CGPath;

//    [self createStrokeAnimation];     // 描线动画
}

- (void)createStrokeAnimation
{
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    animation.duration = 3;
    animation.fromValue = @(0);
    animation.toValue = @(1);
    animation.repeatCount = 100;
    animation.removedOnCompletion = NO;
    animation.fillMode = kCAFillModeForwards;
    [self.shapeLayer addAnimation:animation forKey:nil];
}

#pragma mark - Paths

- (UIBezierPath *)rectPath
{
    //绘制矩形
    UIBezierPath *path = [UIBezierPath bezierPathWithRect:CGRectMake(100, 100, 100, 100)];
    return path;
}

- (UIBezierPath *)roundPath
{
    // 绘制圆形路径
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(100, 100, 100, 100)];
    return path;
}

- (UIBezierPath *)roundRectPath
{
    // 绘制自带圆角的路径
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(100, 100, 100, 100) cornerRadius:30];
    return path;
}

- (UIBezierPath *)rectCornersPath
{
    // 指定矩形某一个角加圆角（例如左上角）
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(100, 100, 100, 100) byRoundingCorners:UIRectCornerTopLeft cornerRadii:CGSizeMake(50, 50)];
    return path;
}

- (UIBezierPath *)trianglePath
{
    // 三角形
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(100, 100)];
    [path addLineToPoint:CGPointMake(100, 200)];
    [path addLineToPoint:CGPointMake(200, 200)];
    [path addLineToPoint:CGPointMake(100, 100)];
    return path;
}

- (UIBezierPath *)bazierPath
{
    // 曲线
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(100, 100)];
    [path addCurveToPoint:CGPointMake(300, 100) controlPoint1:CGPointMake(200, 0) controlPoint2:CGPointMake(200, 200)];
    return path;
}

#pragma mark - Property

- (CAShapeLayer *)shapeLayer
{
    if (!_shapeLayer) {
        _shapeLayer = [CAShapeLayer layer];
        _shapeLayer.strokeColor = [UIColor whiteColor].CGColor;
        _shapeLayer.fillColor = [UIColor colorWithRed:0 green:0.63 blue:1 alpha:1].CGColor;
        _shapeLayer.lineWidth = 3;
    }
    return _shapeLayer;
}

@end
