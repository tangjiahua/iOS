//
//  main.m
//  aniamtion-demo-emitter
//
//  Created by lianweiqin on 2019/7/3.
//  Copyright © 2019 连伟钦. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
