//
//  ViewController.m
//  aniamtion-demo-emitter
//
//  Created by lianweiqin on 2019/7/3.
//  Copyright © 2019 连伟钦. All rights reserved.
//

#import "ViewController.h"
#import "EmitterBkgView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    EmitterBkgView *emitterView = [[EmitterBkgView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    [self.view addSubview:emitterView];
}


@end
