//
//  EmitterBkgView.m
//  aniamtion-demo-emitter
//
//  Created by lianweiqin on 2019/7/3.
//  Copyright © 2019 Bytedance. All rights reserved.
//

#import "EmitterBkgView.h"

@implementation EmitterBkgView {
    CAGradientLayer *_gradientLayer;            // 渐变背景色
    CAEmitterLayer *_snowLayer;                 // 下雪天
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self createGradientLayer];
        [self createSnowLayer];
    }
    return self;
}

- (void)layoutSubviews
{
    [CATransaction begin];
    [CATransaction setDisableActions:YES]; //关闭隐式动画
    _gradientLayer.frame = self.bounds;
    _snowLayer.frame = self.bounds;
    [CATransaction commit];

    [super layoutSubviews];
}

- (void)createGradientLayer
{
    _gradientLayer = [CAGradientLayer layer];
    _gradientLayer.frame = self.bounds;
    _gradientLayer.startPoint = CGPointMake(1, 0.5);
    _gradientLayer.endPoint = CGPointMake(0, 0.5);
    _gradientLayer.colors = @[ (__bridge id)[UIColor colorWithRed:0 green:0.63 blue:1 alpha:1].CGColor, (__bridge id)[UIColor colorWithRed:0 green:0.4 blue:0.8 alpha:1].CGColor ];
    _gradientLayer.locations = @[ @(0.0f), @(1.0f) ];
    [self.layer addSublayer:_gradientLayer];
}

- (void)createSnowLayer
{
    _snowLayer = [CAEmitterLayer layer];
    _snowLayer.frame = self.bounds;
    _snowLayer.masksToBounds = YES; // 让emitter不超过范围
    _snowLayer.emitterPosition = CGPointMake(self.frame.size.width / 2.0, -30);
    _snowLayer.emitterSize = CGSizeMake(self.frame.size.width, 0);
    _snowLayer.emitterShape = kCAEmitterLayerLine;
    _snowLayer.emitterMode = kCAEmitterLayerSurface;
    _snowLayer.renderMode = @"oldestLast";

    CAEmitterCell* snowflake = [CAEmitterCell emitterCell];

    snowflake.birthRate = 2; // 粒子产生速率
    snowflake.lifetime = 120;
    snowflake.alphaRange = 1;
    snowflake.scaleRange = 0.5;
    snowflake.lifetimeRange = 20;
    snowflake.velocity = 0;
    snowflake.velocityRange = 100;
    snowflake.xAcceleration = 0;
    snowflake.yAcceleration = 0;
    snowflake.emissionRange = 0.5 * M_PI;

    snowflake.contents = (id)[UIImage imageNamed:@"snow.png"].CGImage;

    _snowLayer.emitterCells = [NSArray arrayWithObject:snowflake];

    [self.layer insertSublayer:_snowLayer above:_gradientLayer];
}

@end
