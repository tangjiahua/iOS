//
//  ViewController.m
//  animation-demo-waterwave
//
//  Created by lianweiqin on 2019/7/2.
//  Copyright © 2019 连伟钦. All rights reserved.
//

#import "ViewController.h"
#import "WaterWaveView.h"

@interface ViewController ()

@property (nonatomic, strong) WaterWaveView *wave;
@property (nonatomic, strong) UISlider *slider;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    WaterWaveView *wave = [[WaterWaveView alloc] initWithFrame:CGRectMake(100, 100, 200, 200)];
    wave.layer.borderColor = [UIColor colorWithRed:0.1 green:0.1 blue:0.1 alpha:0.1].CGColor;
    wave.layer.borderWidth = 3;
    [wave startWave];
    [self.view addSubview:wave];

    self.slider = [[UISlider alloc] initWithFrame:CGRectMake(50, 400, 300, 30)];
    [self.slider addTarget:self action:@selector(onSliderMoved) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:self.slider];

    self.wave = wave;
}

- (void)onSliderMoved
{
    [self.wave setProgress:self.slider.value];
}

@end
