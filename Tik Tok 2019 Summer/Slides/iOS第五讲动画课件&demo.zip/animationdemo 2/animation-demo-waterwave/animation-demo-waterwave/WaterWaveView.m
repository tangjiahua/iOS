//
//  WaterWaveView.m
//  animation-demo-waterwave
//
//  Created by lianweiqin on 2019/7/2.
//  Copyright © 2019 连伟钦. All rights reserved.
//

#import "WaterWaveView.h"

@interface WaterWaveView()

@property (nonatomic, strong) CADisplayLink *waveDisplaylink;

@property (nonatomic, strong) CAShapeLayer *frontWaveLayer;
@property (nonatomic, strong) CAShapeLayer *behindWaveLayer;

@end

@implementation WaterWaveView {
    CGFloat _waveAmplitude; // 波纹振幅
    CGFloat _waveCycle;        // 波纹周期
    CGFloat _waveSpeed;        // 波纹速度
    CGFloat _waveGrowth;    // 波纹上升速度

    CGFloat _waterWaveHeight;
    CGFloat _waterWaveWidth;
    CGFloat _offsetX;            // 波浪x位移
    CGFloat _currentWavePointY; // 当前波浪上市高度Y（高度从大到小 坐标系向下增长）

    float _variable; // 不可言说的参数 振幅相关
    BOOL _increase;  // 增减变化
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.layer.masksToBounds = YES;
        _waterWaveHeight = self.frame.size.height / 2;
        _waterWaveWidth = self.frame.size.width;
        _frontWaveColor = [UIColor colorWithRed:0 green:0.63 blue:1 alpha:1];
        _behindWaveColor = [UIColor colorWithRed:0 green:0.63 blue:1 alpha:0.5];

        _waveGrowth = 0.85;
        _waveSpeed = 0.4 / M_PI;
        [self resetProperty];
    }
    return self;
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    _waterWaveHeight = self.frame.size.height / 2;
    _waterWaveWidth = self.frame.size.width;
    if (_waterWaveWidth > 0) {
        _waveCycle = 1.29 * M_PI / _waterWaveWidth;
    }

    if (_currentWavePointY <= 0) {
        _currentWavePointY = self.frame.size.height;
    }

    self.layer.cornerRadius = self.frame.size.width / 2;
}

- (void)resetProperty
{
    _currentWavePointY = self.frame.size.height;

    _variable = 1.6;
    _increase = NO;

    _offsetX = 0;
}

- (void)startWave
{
    if (_frontWaveLayer == nil) {
        // 创建第一个波浪Layer
        _frontWaveLayer = [CAShapeLayer layer];
        _frontWaveLayer.fillColor = _frontWaveColor.CGColor;
        [self.layer addSublayer:_frontWaveLayer];
    }

    if (_behindWaveLayer == nil) {
        // 创建第二个波浪Layer
        _behindWaveLayer = [CAShapeLayer layer];
        _behindWaveLayer.fillColor = _behindWaveColor.CGColor;
        [self.layer addSublayer:_behindWaveLayer];
    }

    if (_waveDisplaylink == nil) {
        // 启动定时调用
        _waveDisplaylink = [CADisplayLink displayLinkWithTarget:self selector:@selector(getCurrentWave:)];
        [_waveDisplaylink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    }
}

- (void)reset
{
    [self stopWave];
    [self resetProperty];

    if (_frontWaveLayer) {
        [_frontWaveLayer removeFromSuperlayer];
        _frontWaveLayer = nil;
    }

    if (_behindWaveLayer) {
        [_behindWaveLayer removeFromSuperlayer];
        _behindWaveLayer = nil;
    }
}

- (void)animateWave
{
    if (_increase) {
        _variable += 0.01;
    } else {
        _variable -= 0.01;
    }

    if (_variable <= 1) {
        _increase = YES;
    }

    if (_variable >= 1.6) {
        _increase = NO;
    }

    _waveAmplitude = _variable * 5;
}

- (void)getCurrentWave:(CADisplayLink*)displayLink
{
    [self animateWave];

    if (_waveGrowth > 0 && _currentWavePointY > 2 * _waterWaveHeight * (1 - _progress)) {
        // 波浪高度未到指定高度 继续上涨
        _currentWavePointY -= _waveGrowth;
    } else if (_waveGrowth < 0 && _currentWavePointY < 2 * _waterWaveHeight * (1 - _progress)) {
        _currentWavePointY -= _waveGrowth;
    }

    // 波浪位移
    _offsetX += _waveSpeed;

    [self setCurrentFrontWaveLayerPath];

    [self setCurrentBehindWaveLayerPath];
}

- (void)setCurrentFrontWaveLayerPath
{
    UIBezierPath *path = [UIBezierPath bezierPath];
    CGFloat y = _currentWavePointY;
    [path moveToPoint:CGPointMake(0, y)];
    for (float x = 0.0f; x <= _waterWaveWidth; x++) {
        // 正弦波浪公式
        y = _waveAmplitude * sin(_waveCycle * x + _offsetX) + _currentWavePointY;
        [path addLineToPoint:CGPointMake(x, y)];
    }
    [path addLineToPoint:CGPointMake(_waterWaveWidth, self.frame.size.height)];
    [path addLineToPoint:CGPointMake(0, self.frame.size.height)];

    _frontWaveLayer.path = path.CGPath;
}

- (void)setCurrentBehindWaveLayerPath
{
    UIBezierPath *path = [UIBezierPath bezierPath];
    CGFloat y = _currentWavePointY;
    [path moveToPoint:CGPointMake(0, y)];
    for (float x = 0.0f; x <= _waterWaveWidth; x++) {
        // 余弦波浪公式
        y = _waveAmplitude * cos(_waveCycle * x + _offsetX) + _currentWavePointY;
        [path addLineToPoint:CGPointMake(x, y)];
    }
    [path addLineToPoint:CGPointMake(_waterWaveWidth, self.frame.size.height)];
    [path addLineToPoint:CGPointMake(0, self.frame.size.height)];

    _behindWaveLayer.path = path.CGPath;
}

- (void)stopWave
{
    if (_waveDisplaylink) {
        [_waveDisplaylink invalidate];
        _waveDisplaylink = nil;
    }
}

- (void)dealloc
{
    [self reset];
}

#pragma mark - Property

- (void)setFrontWaveColor:(UIColor*)frontWaveColor
{
    _frontWaveColor = frontWaveColor;
    _frontWaveLayer.fillColor = frontWaveColor.CGColor;
}

- (void)setBehindWaveColor:(UIColor*)behindWaveColor
{
    _behindWaveColor = behindWaveColor;
    _behindWaveLayer.fillColor = behindWaveColor.CGColor;
}

- (void)setProgress:(CGFloat)progress
{
    if (_progress > progress) {
        // 下降
        _waveGrowth = _waveGrowth > 0 ? -_waveGrowth : _waveGrowth;
    } else if (_progress < progress) {
        // 上升
        _waveGrowth = _waveGrowth > 0 ? _waveGrowth : -_waveGrowth;
    }
    _progress = progress;
}

@end
