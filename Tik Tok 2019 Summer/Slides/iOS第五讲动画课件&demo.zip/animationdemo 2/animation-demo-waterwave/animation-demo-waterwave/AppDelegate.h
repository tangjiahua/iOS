//
//  AppDelegate.h
//  animation-demo-waterwave
//
//  Created by lianweiqin on 2019/7/2.
//  Copyright © 2019 连伟钦. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

