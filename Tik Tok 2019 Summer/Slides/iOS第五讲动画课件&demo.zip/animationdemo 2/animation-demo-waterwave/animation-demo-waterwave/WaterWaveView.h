//
//  WaterWaveView.h
//  animation-demo-waterwave
//
//  Created by lianweiqin on 2019/7/2.
//  Copyright © 2019 连伟钦. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WaterWaveView : UIView

/**
 *  前面波浪的颜色
 */
@property (nonatomic, strong) UIColor* frontWaveColor;

/**
 *  后面波浪的颜色
 */
@property (nonatomic, strong) UIColor* behindWaveColor;

/**
 *  进度百分比
 */
@property (nonatomic) CGFloat progress;

/**
 *  开始浪
 */
- (void)startWave;

/**
 *  停止浪
 */
- (void)stopWave;

/**
 *  破浪潮!
 */
- (void)reset;

@end

NS_ASSUME_NONNULL_END
