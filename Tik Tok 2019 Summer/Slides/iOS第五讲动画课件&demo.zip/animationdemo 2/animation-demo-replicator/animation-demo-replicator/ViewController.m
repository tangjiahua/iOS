//
//  ViewController.m
//  animation-demo-replicator
//
//  Created by lianweiqin on 2019/7/14.
//  Copyright © 2019 连伟钦. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor blackColor];

    CAReplicatorLayer *layer = [CAReplicatorLayer layer];   // 复制层
    layer.frame = CGRectMake(150, 200, 100, 100);
    [self.view.layer addSublayer:layer];

    CALayer *circle = [CALayer layer];
    circle.bounds = CGRectMake(50, 0, 16, 16);
    circle.cornerRadius = 8;
    circle.backgroundColor = [UIColor whiteColor].CGColor;
    [layer addSublayer:circle];

    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    animation.fromValue = @1.0;
    animation.toValue = @0.1;
    animation.repeatCount = HUGE;
    animation.duration = 1;
    [circle addAnimation:animation forKey:nil];

    layer.instanceCount = 15;
    layer.instanceTransform = CATransform3DMakeRotation((2 * M_PI) / 15.0, 0, 0, 1);
    layer.instanceDelay = 1.0 / 15;
}


@end
