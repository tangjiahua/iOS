//
//  ViewController.m
//  animation-demo-interactive
//
//  Created by lianweiqin on 2019/7/14.
//  CopyrighDt © 2019 ByteDance. All rights reserved.
//

#import "ViewController.h"

#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width

@interface ViewController ()

@property (nonatomic, strong) UIView *cardView;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    [self.view addSubview:self.cardView];

    UIPanGestureRecognizer *gesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
    [self.view addGestureRecognizer:gesture];
}

- (void)handlePanGesture:(UIPanGestureRecognizer *)pan
{
    static CGPoint initialPoint;
    CGPoint transition = [pan translationInView:self.view];
    if (pan.state == UIGestureRecognizerStateBegan) {
        initialPoint = self.cardView.center;
    } else if(pan.state == UIGestureRecognizerStateChanged) {
        self.cardView.center = CGPointMake(initialPoint.x + transition.x, initialPoint.y + transition.y);

        // 根据距离算 alpha
        CGFloat distance = sqrt(pow(transition.x, 2) + pow(transition.y, 2));
        self.cardView.alpha = (800.f - distance) / 800.f;
    } else if ((pan.state == UIGestureRecognizerStateEnded) || (pan.state == UIGestureRecognizerStateCancelled)) {
        [UIView animateWithDuration:0.5
                              delay:0.0f
             usingSpringWithDamping:0.6
              initialSpringVelocity:0.0f
                            options:UIViewAnimationOptionCurveEaseInOut animations:^{
                                // 还原属性
                                self.cardView.center = initialPoint;
                                self.cardView.alpha = 1;
                            }
                         completion:nil];
    }
}

#pragma mark - Property

- (UIView *)cardView
{
    if (!_cardView) {
        _cardView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 200, 100)];
        _cardView.backgroundColor = [UIColor colorWithRed:0 green:0.63 blue:1 alpha:1];
        _cardView.center = self.view.center;
    }
    return _cardView;
}

@end
